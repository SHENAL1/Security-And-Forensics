#include "config.h"
#include "libexif/i18n.h"

#include <stdio.h>

int main()
{
  puts(LOCALEDIR);
  puts("\n");
  return 0;
}
