#ifndef _TSK_INCS_H
#define _TSK_INCS_H
// automatically by ./configure
// Contains the config.h data needed by programs that use libtsk

#include <unistd.h>
#ifndef __STDC_FORMAT_MACROS
#define  __STDC_FORMAT_MACROS
#endif
#include <inttypes.h>
#include <sys/param.h>
#define TSK_MULTITHREAD_LIB // enable multithreading

#endif
